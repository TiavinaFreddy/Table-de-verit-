#table de verité d'un fonction logique de 3 avriables
#les variables sont a,b,c
print("table de verité et forme canonique  d'une fonction logique avec les variables a,b,c")
z=input("entrer la fonction logique en utilisant les operateurs 'and','or','not' ")
f=lambda a,b,c:eval(z)

joindre=["a","b","c",str(z)]
print(" | ".join(joindre))
for a in range(0,2):
    for b in range (0,2):
        for c in range (0,2):
            print(" | ".join([str(a),str(b),str(c),str(f(a,b,c))]))


if f(0,0,0)==1 or f(0,0,0)==True:
    q=" non(a)non(b)non(c)"
    Q=""
elif f(0,0,0)==0 or f(0,0,0)==False:
    Q="(a+b+c)"
    q=""

if f(0,0,1)==1 or f(0,0,1)==True:
    w="+ non(a)non(b)c"
    W=""
elif f(0,0,1)==0 or f(0,0,1)==False:
    W="(a+b+non(c))"
    w=""

if f(0,1,0)==1 or f(0,1,0)==True:
    e="+ non(a)bnon(c)"
    E=""
elif f(0,1,0)==0 or f(0,1,0)==False:
    E="(a+non(b)+c)"
    e=""

if f(0,1,1)==1 or f(0,1,1)==True:
    r="+ non(a)bc"
    R=""
elif f(0,1,1)==0 or f(0,1,1)==False:
    R="(a+non(b)+non(c))"
    r=""

if f(1,0,0)==1 or f(1,0,0)==True:
    t="+ anon(b)non(c)"
    T=""
elif f(1,0,0)==0 or f(1,0,0)==False:
    T="(non(a)+b+c)"
    t=""
if f(1,0,1)==1 or f(1,0,1)==True:
    y="+ anon(b)c"
    Y=""
elif f(1,0,1)==0 or f(1,0,1)==False:
    Y="(non(a)+b+non(c)"
    y=""
if f(1,1,0)==1 or f(1,1,0)==True:
    u="+ abnon(c)"
    U=""
elif f(1,1,0)==0 or f(1,1,0)==False:
    U="(non(a)+non(b)+c)"
    u=""
if f(1,1,1)==1 or f(1,1,1)==True:
    i="+ abc"
    I=""
elif f(1,1,1)==0 or f(1,1,1)==False:
    I="(non(a)+non(b)+non(c))"
    i=""
print("le premier forme canonique est")
print(q,w,e,r,t,y,u,i)
print("le deuxieme forme canonique est" )
print(Q,W,E,R,T,Y,U,I)